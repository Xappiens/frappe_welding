from frappe import _

def get_data():
	return [
		{
			"module_name": "Frappe Welding",
			"type": "module",
			"icon": "fa fa-getting-started",
			"color": "grey",
			"label": _("Frappe Welding")
		}
	]
