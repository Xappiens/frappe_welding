// Copyright (c) 2025, Xappiens and contributors
// For license information, please see license.txt

frappe.ui.form.on('Posiciones de soldadura', {
	// refresh: function(frm) {

	// }
});
