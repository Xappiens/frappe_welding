frappe.ui.form.on('Prueba Certificacion', {
    homologación: function(frm) {
        // If no homologation is selected, clear the table and refresh
        if (!frm.doc.homologación) {
            frm.clear_table('procedimiento_wps');
            frm.refresh_field('procedimiento_wps');
            return;
        }

        // Fetch the relevant WPS related to the Prueba Certificación (test certification)
        frappe.call({
            method: 'frappe.client.get',
            args: {
                doctype: 'Homologacion',
                filters: { 'name': frm.doc.homologación }
            },
            callback: function(response) {
                var homologation = response.message;

                if (!homologation || !Array.isArray(homologation.procedimiento_wps)) {
                    frappe.msgprint(__('No valid procedimiento_wps found.'));
                    return;
                }

                // Map out the procedimiento names
                var wps_names = homologation.procedimiento_wps.map(item => item.procedimiento);

                // Clear and populate the procedimiento_wps table if the field exists
                if (frm.fields_dict['procedimiento_wps']) {
                    frm.clear_table('procedimiento_wps');
                    wps_names.forEach(function(wps_name) {
                        var row = frm.add_child('procedimiento_wps');
                        row.procedimiento = wps_name;
                    });
                    frm.refresh_field('procedimiento_wps');
                } else {
                    console.error('No "procedimiento_wps" field found in the form.');
                }
            }
        });
    }
});
